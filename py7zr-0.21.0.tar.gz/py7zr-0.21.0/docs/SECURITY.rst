Security Policy
===============

Supported Versions
------------------

+---------+---------------------+
| Version | Status              |
+=========+=====================+
| 0.20.x  | Stable version      |
+---------+---------------------+
| 0.19.x  | Security fixes only |
+---------+---------------------+
| 0.18.x  | Security fixes only |
+---------+---------------------+
| < 0.18  | not supported       |
+---------+---------------------+

Reporting a Vulnerability
-------------------------

Please disclose security vulnerabilities privately at miurahr@linux.com
