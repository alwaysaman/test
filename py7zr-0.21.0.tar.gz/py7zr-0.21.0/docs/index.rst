===============================
py7zr -- a 7z library on python
===============================

.. toctree::
   :maxdepth: 3

   user_guide
   SECURITY
   api
   contribution
   CODE_OF_CONDUCT
   archive_format
   authors
   glossary
   Changelog
   previous_changes

==================
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
