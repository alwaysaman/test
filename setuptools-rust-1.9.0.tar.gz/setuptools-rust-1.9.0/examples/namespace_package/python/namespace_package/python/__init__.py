def python_func():
    return 15
